package a.svecw.original;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class New3 extends AppCompatActivity {
    TextView t1, t2, t3, t4, t5, t6;
    Button b1, b2;
    String etmessage1 = "Your request for FOODPERMISSION is accepted";
    String etmessage2 = "Your request for FOODPERMISSION is rejected";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new4);
        t1 = findViewById(R.id.t1);
        t2 = findViewById(R.id.t2);
        t3 = findViewById(R.id.t3);
        t4 = findViewById(R.id.t4);
        t5 = findViewById(R.id.t5);
        t6 = findViewById(R.id.t6);
        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);

        String x1 = getIntent().getStringExtra("name");
        String x2 = getIntent().getStringExtra("regno");
        String x3 = getIntent().getStringExtra("hostel");
        String x4 = getIntent().getStringExtra("roomno");
        String x5 = getIntent().getStringExtra("reason");

        String x6 = getIntent().getStringExtra("phone");

        t1.setText(x1);
        t2.setText(x2);
        t3.setText(x3);
        t4.setText(x4);
        t5.setText(x5);
        t6.setText(x6);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(ContextCompat.checkSelfPermission(New3.this, Manifest.permission.SEND_SMS)== PackageManager.PERMISSION_GRANTED){
                    sendMessage1();
                }
                else{
                    ActivityCompat.requestPermissions(New3.this,new String[]{Manifest.permission.SEND_SMS},100);
                }
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ContextCompat.checkSelfPermission(New3.this, Manifest.permission.SEND_SMS)== PackageManager.PERMISSION_GRANTED){
                    sendMessage2();
                }
                else{
                    ActivityCompat.requestPermissions(New3.this,new String[]{Manifest.permission.SEND_SMS},100);
                }
            }
        });

    }
    private  void sendMessage1(){
        String sphone = t6.getText().toString().trim();
        String sMessage =etmessage1;
        if(!sphone.equals("")&&!sMessage.equals("")){
            SmsManager smsManager =SmsManager.getDefault();
            smsManager.sendTextMessage(sphone,null,sMessage,null,null);
            Toast.makeText(getApplicationContext(),"SMS sent successfully!",Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(getApplicationContext(),"Enter value first",Toast.LENGTH_SHORT).show();
        }
    }
    private  void sendMessage2(){
        String sphone = t6.getText().toString().trim();
        String sMessage =etmessage2;
        if(!sphone.equals("")&&!sMessage.equals("")){
            SmsManager smsManager =SmsManager.getDefault();
            smsManager.sendTextMessage(sphone,null,sMessage,null,null);
            Toast.makeText(getApplicationContext(),"SMS sent successfully!",Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(getApplicationContext(),"Enter value first",Toast.LENGTH_SHORT).show();
        }
    }
}
