package a.svecw.original;

import android.os.Bundle;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Ratingrequests  extends AppCompatActivity {
    RecyclerView recyclerView;
    // creating database reference
    DatabaseReference database;
    //creating  object of MyAdapter4 class
    MyAdapter4 myAdapter;
    //creating  arraylist of type Userrating
    ArrayList<Userrating> list;
    Button b1,b2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //connecting the components of connected xml file
        setContentView(R.layout.ratingrequests);
        recyclerView = findViewById(R.id.userlist);
        //Accessing firebase database to path Ratingper
        database = FirebaseDatabase.getInstance().getReference("Ratingper");
        recyclerView.setHasFixedSize(false);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list = new ArrayList<>();
        //calling constructer of Myadapter4 class
        myAdapter = new MyAdapter4(this,list);
        //adding MyAdapter2 object to recycler view
        recyclerView.setAdapter(myAdapter);
        //adding the data one by one present in given Rating per database to recycler view list
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                    Userrating user = (Userrating) dataSnapshot.getValue(Userrating.class);
                    list.add(user);

                }

                myAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
}
