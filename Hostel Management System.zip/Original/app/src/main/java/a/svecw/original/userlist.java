package a.svecw.original;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class userlist extends AppCompatActivity implements MyAdapter.OnNoteListener{

    RecyclerView recyclerView;
    // creating database reference
    DatabaseReference database;
    //creating  object of MyAdapter class
    MyAdapter myAdapter;
    //creating  arraylist of type User food
    ArrayList<User> list;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Connecting corresponnding xml file
        setContentView(R.layout.complaintrequests);

        recyclerView = findViewById(R.id.userlist);
        //Accessing firebase database to path foodper
        database =FirebaseDatabase.getInstance().getReference("Complaintper");

        recyclerView.setHasFixedSize(false);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list = new ArrayList<>();
        //calling constructer of Myadapter class
        myAdapter = new MyAdapter(this,list,this::onNoteClick);
        //adding MyAdapter3 object to recycler view
        recyclerView.setAdapter(myAdapter);
        //adding the data one by one present in given Food per database to recycler view list
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                    User user = (User)dataSnapshot.getValue(User.class);
                    list.add(user);

                }

                myAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    //Setting onclick of an item in list to perform a action
    @Override
    public void onNoteClick(int position) {
        //getting the data at the item clicked in recycler view list
        Intent newintent = new Intent(getApplicationContext(), New2.class);
        User user1 =list.get(position);
        //Storing the data from database of clicked item to transfer to another screen
        newintent.putExtra("name",user1.getName());
        newintent.putExtra("regno",user1.getReg());
        newintent.putExtra("hostel",user1.getHostel());
        newintent.putExtra("roomno",user1.getRoomno());
        newintent.putExtra("complaint",user1.getComplaint());
        newintent.putExtra("phone",user1.getPhone());
        startActivity(newintent);
    }
}
