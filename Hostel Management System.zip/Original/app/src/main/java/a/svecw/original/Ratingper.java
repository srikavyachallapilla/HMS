package a.svecw.original;

public class Ratingper {
    //listing all credentials filled in Feedback permissions xml
    String worker,work,rating;
    //creating corresponding parameterised constructor with all credentials as parameters
    public Ratingper(String worker, String work, String rating) {
        this.worker = worker;
        this.work = work;
        this.rating = rating;
    }
    //Creating getter setter for all credentials

    public String getWorker() {
        return worker;
    }

    public void setWorker(String worker) {
        this.worker = worker;
    }

    public String getWork() {
        return work;
    }

    public void setWork(String work) {
        this.work = work;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }
}
