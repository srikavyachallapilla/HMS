package a.svecw.original;

public class User {


    //list all credentials that are stored in Complaintper path firebasedatabase
    String name,regno,hostel,roomno,complaint,phone;


    //create getter and setters for all credentials
    public String getName() {
        return name;
    }

    public String getReg() {
        return regno;
    }

    public String getHostel() {
        return hostel;
    }

    public String getRoomno() {
        return roomno;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRegno(String regno) {
        this.regno = regno;
    }

    public void setHostel(String hostel) {
        this.hostel = hostel;
    }

    public void setRoomno(String roomno) {
        this.roomno = roomno;
    }

    public void setComplaint(String complaint) {
        this.complaint = complaint;
    }

    public String getComplaint() {
        return complaint;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
