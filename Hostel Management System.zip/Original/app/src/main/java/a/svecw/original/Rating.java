package a.svecw.original;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.content.Context;
import android.os.Bundle;
import android.view.View;

import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Rating extends AppCompatActivity {
    EditText e1,e2;
    //Creating database referenece
    DatabaseReference rating;

    final Context context =this;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Connecting corresponnding xml file
        setContentView(R.layout.rating);
        //connecting the components of connected xml file

        e1=findViewById(R.id.e1);
        e2=findViewById(R.id.e2);
        //creating database with branch Ratingper for firebasedatabase
        rating= FirebaseDatabase.getInstance().getReference().child("Ratingper");
        final RatingBar simpleRatingBar = (RatingBar) findViewById(R.id.simpleRatingBar);
        Button submitButton = (Button) findViewById(R.id.submitButton);

        //on click submit store the credentials filled to database

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Getting all credentials filled into string form
                String totalStars = "Total Stars:: " + simpleRatingBar.getNumStars();
                String x= String.valueOf(simpleRatingBar.getRating());
                String y =e1.getText().toString();
                String z =e2.getText().toString();

                //Calling constructor with all credentials as parameters of Ratingper class
                Ratingper ratingper = new Ratingper(y,z,x);
                //pushing the object to store data into Firebasedatabase
                rating.push().setValue(ratingper);
                String rating = "Rating :: " + simpleRatingBar.getRating();
                Toast.makeText(getApplicationContext(), totalStars + "\n" + rating, Toast.LENGTH_LONG).show();
            }
        });

        Button logoutButton = (Button) findViewById(R.id.logoutButton);
        //on click go to intial login screen by logining out
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, MainActivity.class);
                startActivity(intent);
            }
        });
    }


}
