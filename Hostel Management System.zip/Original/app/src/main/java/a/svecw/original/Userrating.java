package a.svecw.original;

public class Userrating {
    //list all credentials that are stored in Hospitalper path firebasedatabase
    String rating,work,worker;
    //create getter and setters for all credentials

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getWork() {
        return work;
    }

    public void setWork(String work) {
        this.work = work;
    }

    public String getWorker() {
        return worker;
    }

    public void setWorker(String worker) {
        this.worker = worker;
    }
}
