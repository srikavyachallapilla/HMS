package a.svecw.original;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
    TextView t1;
    EditText e1,e2;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Connecting xml file
        setContentView(R.layout.activity_main);
        //connecting components of corresponding xml file connected
        t1=findViewById(R.id.t1);
        e1=findViewById(R.id.e1);
        e2=findViewById(R.id.e2);
        b1=findViewById(R.id.b1);
        //Checking login credentials on submit of regno and password
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Checking if  username or password is empty
                if(e1.getText().toString().equals("")||e2.getText().toString().equals("")) {

                    Toast.makeText(MainActivity.this,"regno and password cannot be empty",Toast.LENGTH_SHORT).show();

                }
                //checking if given credentials belong to admin
                else if(e1.getText().toString().equals("admin")&&e2.getText().toString().equals("admin123")){
                    //login for admin option screen
                    Intent newintent = new Intent(getApplicationContext(), Admin1.class);
                    startActivity(newintent);
                }
                //checking if given credentials belong to student
                else if((e1.getText().toString().equals("17b01a0502")||e1.getText().toString().equals("17b01a0550")||e1.getText().toString().equals("17b01a0517")||e1.getText().toString().equals("17b01a0515"))&&(e2.getText().toString().equals("webcap"))){
                    //login for student option screen
                    Intent newintent = new Intent(getApplicationContext(), Student.class);
                    startActivity(newintent);
                    //Toast.makeText(Hostel8.this,"regno and password perfect",Toast.LENGTH_SHORT).show();

                }
                else{

                    Toast.makeText(MainActivity.this,"Wrong regno or Wrong password",Toast.LENGTH_SHORT).show();

                }
            }
        });

    }
}
