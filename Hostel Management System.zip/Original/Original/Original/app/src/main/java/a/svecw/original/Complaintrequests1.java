package a.svecw.original;

import android.os.Bundle;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Complaintrequests1 extends AppCompatActivity {
    EditText e1,e2;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.complaintrequests1);
        e1=findViewById(R.id.e1);
        e2=findViewById(R.id.e2);
        final String TempHolder = getIntent().getStringExtra("selectedvalue1");
        e1.setText(TempHolder);
        DatabaseReference x= FirebaseDatabase.getInstance().getReference().getParent();

    }
}
