package a.svecw.original;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Complaintrequests extends AppCompatActivity {
    final List<String> datalist =new ArrayList<String>();
    TextView t1;
    ListView listView1;
    DataSnapshot dataSnapshot1;

    FirebaseDatabase database=FirebaseDatabase.getInstance();
    DatabaseReference databaseReference=database.getReference().child("Complaintper");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.complaintrequests);
        t1=findViewById(R.id.t1);


        listView1=(ListView)findViewById(R.id.userlist);

      //  System.out.println(databaseReference.child("Complaintper"));
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
               // System.out.println(snapshot.getChildrenCount());
                datalist.clear();
                for(DataSnapshot ds:snapshot.getChildren()){
                    datalist.add(ds.child("regno").getValue().toString());

                    ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(Complaintrequests.this,android.R.layout.simple_expandable_list_item_1,datalist);
                    listView1.setAdapter(arrayAdapter);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


       /* listView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //String TempHolder1 =

                //System.out.println(dataSnapshot1.getValue().toString());
                Intent newintent = new Intent(getApplicationContext(), Complaintrequests1.class);
               String TempHolder = listView1.getItemAtPosition(i).toString();
              // DatabaseReference x= FirebaseDatabase.getInstance().getReference().child("");
               //System.out.println(TempHolder);

                //newintent.putExtra("select",TempHolder1);
                newintent.putExtra("selectedvalue1", TempHolder);
                startActivity(newintent);
            }
        });
      /*  databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot ds:dataSnapshot.getChildren()){
                    String x = ds.child("name").getValue().toString();
                    String x1=ds.child("regno").getValue().toString();
                    String y = ds.child("hostelname").getValue().toString();
                    //String z = ds.child("reason").getValue().toString();
                    String w = ds.child("roomno").getValue().toString();
                    String c = ds.child("complaint").getValue().toString();
                    datalist.add(x);
                    datalist.add(y);
                    //datalist.add(z);
                    datalist.add(w);
                    datalist.add(x1);
                    datalist.add(c);
                    ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(Complaintrequests.this, android.R.layout.simple_list_item_multiple_choice,datalist);
                    listView1.setAdapter(arrayAdapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        /*databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for(DataSnapshot ds:dataSnapshot.getChild("Complaintper")) {

                    String x = ds.child("name").getValue().toString();
                    String x1=ds.child("regno").getValue().toString();
                    String y = ds.child("hostelname").getValue().toString();
                    String z = ds.child("reason").getValue().toString();
                    String w = ds.child("roomno").getValue().toString();
                    String c = ds.child("complaint").getValue().toString();
                    datalist.add(x);
                    datalist.add(y);
                    datalist.add(z);
                    datalist.add(w);
                    datalist.add(x1);
                    datalist.add(c);
                    ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(Complaintrequests.this, android.R.layout.simple_list_item_multiple_choice,datalist);
                    listView1.setAdapter(arrayAdapter);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });*/
    }
}
